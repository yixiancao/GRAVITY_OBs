from astropy.coordinates import SkyCoord
from astropy.units import arcsec, degree
import requests
import numpy as np
from io import BytesIO
from astropy.table import Table
from astropy.wcs import WCS
from matplotlib import pyplot, collections

def get_finding_chart(target_name):

    target = SkyCoord.from_name(target_name)

    ra = target.ra.to(degree).value
    dec = target.dec.to(degree).value
    radius = (60*arcsec).to(degree).value

    resp = requests.get(f'https://gsss.stsci.edu/webservices/vo/CatalogSearch.aspx?RA={ra:.6f}&DEC={dec:.6f}&SR={radius:.3f}')
    tbl = Table.read(BytesIO(resp.content))

    # %%

    fig, axarr = pyplot.subplots(1, 2, figsize=(8, 4), sharex=True, sharey=True)
    for i, mag_name in enumerate(['gaiaRpMag', 'tmassKsMag']):
        mag = tbl[mag_name]

        mag2size = lambda mag: 50*(np.max(mag)-mag)/(np.max(mag)-np.min(mag))
        size2mag = lambda size: np.max(mag)-(size/50)*(np.max(mag)-np.min(mag))

        axarr[i].plot(ra+10/3600*np.cos(np.linspace(0, 2*np.pi, 1000)), dec+10/3600*np.sin(np.linspace(0, 2*np.pi, 1000)), 'k', lw=1)
        axarr[i].plot(ra+ 5/3600*np.cos(np.linspace(0, 2*np.pi, 1000)), dec+ 5/3600*np.sin(np.linspace(0, 2*np.pi, 1000)), 'k', lw=0.5)
        data = axarr[i].scatter(tbl['ra'], tbl['dec'], mag2size(tbl[mag_name]))
        axarr[i].set_aspect('equal')
        axarr[i].legend(*data.legend_elements(prop='sizes', num=5, func=size2mag), title=mag_name, loc='upper right')
        axarr[i].set_xlim(ra+10/3600, ra-10/3600)
        axarr[i].set_ylim(dec-10/3600, dec+10/3600)
    pyplot.show()
    
    return fig, axarr